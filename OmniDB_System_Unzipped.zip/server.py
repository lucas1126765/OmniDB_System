import socket
import os
import json
import threading
import zlib
import hashlib
import time
import logging
from datetime import datetime
from cryptography.fernet import Fernet
from concurrent.futures import ThreadPoolExecutor
from collections import defaultdict

class OmniDB:
    def __init__(self, data_dir="data", index_file="index.json", users_file="users.json", 
                 backup_dir="backups", log_file="server.log", max_connections=100, 
                 rate_limit=100, compression=True, encryption=True):
        self.data_dir = data_dir
        self.index_file = index_file
        self.users_file = users_file
        self.backup_dir = backup_dir
        self.index = self.load_index()
        self.users = self.load_users()
        self.permissions = self.load_permissions()
        self.versions = self.load_versions()
        self.connection_count = 0
        self.rate_limits = defaultdict(int)
        self.max_connections = max_connections
        self.rate_limit = rate_limit
        self.compression = compression
        self.encryption = encryption
        self.encryption_key = self.load_or_generate_key()
        self.cipher = Fernet(self.encryption_key)
        self.connection_pool = ThreadPoolExecutor(max_workers=max_connections)
        
        # Setup logging
        logging.basicConfig(
            filename=log_file,
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        
        os.makedirs(self.data_dir, exist_ok=True)
        os.makedirs(self.backup_dir, exist_ok=True)

    def load_index(self):
        if os.path.exists(self.index_file):
            with open(self.index_file, "r") as f:
                return json.load(f)
        return {}

    def save_index(self):
        with open(self.index_file, "w") as f:
            json.dump(self.index, f)

    def load_users(self):
        if os.path.exists(self.users_file):
            with open(self.users_file, "r") as f:
                return json.load(f)
        return {}

    def save_users(self):
        with open(self.users_file, "w") as f:
            json.dump(self.users, f)

    def authenticate(self, username, password):
        if username in self.users and self.users[username] == password:
            return True
        return False

    def register_user(self, username, password):
        """註冊新用戶"""
        # 檢查用戶名是否已存在
        if username in self.users:
            return "ERROR: User already exists"
        
        # 添加新用戶
        self.users[username] = password
        self.save_users()
        
        # 為新用戶創建基本權限
        if username not in self.permissions:
            self.permissions[username] = {"*": ["read", "write", "delete", "list"]}
            self.save_permissions()
        
        logging.info(f"New user registered: {username}")
        return "OK"

    def load_or_generate_key(self):
        key_file = "encryption.key"
        if os.path.exists(key_file):
            with open(key_file, "rb") as f:
                return f.read()
        else:
            key = Fernet.generate_key()
            with open(key_file, "wb") as f:
                f.write(key)
            return key

    def load_permissions(self):
        permissions_file = "permissions.json"
        if os.path.exists(permissions_file):
            with open(permissions_file, "r") as f:
                return json.load(f)
        return {}

    def save_permissions(self):
        with open("permissions.json", "w") as f:
            json.dump(self.permissions, f)

    def load_versions(self):
        versions_file = "versions.json"
        if os.path.exists(versions_file):
            with open(versions_file, "r") as f:
                return json.load(f)
        return {}

    def save_versions(self):
        with open("versions.json", "w") as f:
            json.dump(self.versions, f)

    def check_rate_limit(self, client_ip):
        current_time = time.time()
        if current_time - self.rate_limits[client_ip] > 60:
            self.rate_limits[client_ip] = current_time
            return True
        return False

    def compress_data(self, data):
        if self.compression:
            return zlib.compress(data)
        return data

    def decompress_data(self, data):
        if self.compression:
            return zlib.decompress(data)
        return data

    def encrypt_data(self, data):
        if self.encryption:
            return self.cipher.encrypt(data)
        return data

    def decrypt_data(self, data):
        if self.encryption:
            return self.cipher.decrypt(data)
        return data

    def create_backup(self):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_path = os.path.join(self.backup_dir, f"backup_{timestamp}")
        os.makedirs(backup_path)
        
        # Backup index
        with open(os.path.join(backup_path, "index.json"), "w") as f:
            json.dump(self.index, f)
        
        # Backup data files
        for key in self.index:
            src = self.index[key]["path"]
            dst = os.path.join(backup_path, key)
            os.copy2(src, dst)
        
        logging.info(f"Created backup: {backup_path}")
        return backup_path

    def restore_backup(self, backup_path):
        if not os.path.exists(backup_path):
            return "ERROR: Backup not found"
        
        # Restore index
        with open(os.path.join(backup_path, "index.json"), "r") as f:
            self.index = json.load(f)
        self.save_index()
        
        # Restore data files
        for key in self.index:
            src = os.path.join(backup_path, key)
            dst = self.index[key]["path"]
            os.copy2(src, dst)
        
        logging.info(f"Restored from backup: {backup_path}")
        return "OK"

    def check_permission(self, username, key, operation):
        if username not in self.permissions:
            return False
        user_perms = self.permissions[username]
        if "*" in user_perms and operation in user_perms["*"]:
            return True
        if key in user_perms and operation in user_perms[key]:
            return True
        return False

    def put(self, key, data_type, data, username):
        if not self.check_permission(username, key, "write"):
            return "ERROR: Permission denied"
        
        # 檢查文件類型是否有效
        valid_types = ["text", "binary", "image", "video", "audio", "code", "json", "xml"]
        if data_type not in valid_types:
            return f"ERROR: Invalid data type. Supported types: {', '.join(valid_types)}"
        
        # 如果是代碼或特定文件類型，檢查檔案安全性
        if data_type == "code":
            # 以文本形式檢查代碼內容
            try:
                code_content = data.decode('utf-8')
                # 可以在這裡添加代碼安全檢查，例如禁止某些危險函數或命令
                risky_patterns = ["os.system(", "subprocess.call(", "eval(", "exec("]
                for pattern in risky_patterns:
                    if pattern in code_content:
                        return f"ERROR: Code contains potentially unsafe pattern: {pattern}"
            except:
                pass  # 如果無法解碼為文本，則跳過檢查
        
        # Create version
        if key in self.index:
            version = len(self.versions.get(key, [])) + 1
            self.versions.setdefault(key, []).append({
                "version": version,
                "timestamp": datetime.now().isoformat(),
                "size": self.index[key]["size"],
                "type": self.index[key]["type"]
            })
            self.save_versions()
        
        # Process data
        processed_data = self.compress_data(data)
        processed_data = self.encrypt_data(processed_data)
        
        file_path = os.path.join(self.data_dir, key)
        with open(file_path, "wb") as f:
            f.write(processed_data)
        
        self.index[key] = {
            "type": data_type,
            "size": len(processed_data),
            "path": file_path,
            "original_size": len(data),
            "compressed": self.compression,
            "encrypted": self.encryption,
            "last_modified": datetime.now().isoformat(),
            "modified_by": username
        }
        self.save_index()
        logging.info(f"PUT operation: {key} ({data_type}) by {username}")
        return "OK"

    def get(self, key, username):
        if not self.check_permission(username, key, "read"):
            return "ERROR", 0, b""
        
        if key in self.index:
            with open(self.index[key]["path"], "rb") as f:
                data = f.read()
            
            data = self.decrypt_data(data)
            data = self.decompress_data(data)
            
            logging.info(f"GET operation: {key} by {username}")
            return self.index[key]["type"], len(data), data
        else:
            return "ERROR", 0, b""

    def delete(self, key, username):
        if not self.check_permission(username, key, "delete"):
            return "ERROR: Permission denied"
        
        if key in self.index:
            os.remove(self.index[key]["path"])
            del self.index[key]
            self.save_index()
            logging.info(f"DELETE operation: {key} by {username}")
            return "OK"
        else:
            return "ERROR"

    def list(self, username):
        if not self.check_permission(username, "*", "list"):
            return []
        
        return [key for key in self.index.keys() 
                if self.check_permission(username, key, "read")]

    def handle_client(self, conn, addr):
        client_ip = addr[0]
        if not self.check_rate_limit(client_ip):
            conn.sendall(b"ERROR: Rate limit exceeded")
            conn.close()
            return
        
        self.connection_count += 1
        if self.connection_count > self.max_connections:
            conn.sendall(b"ERROR: Maximum connections reached")
            conn.close()
            self.connection_count -= 1
            return
        
        print(f"Connected by {addr}")
        authenticated = False
        username = ''
        
        try:
            while True:
                data = conn.recv(4096)
                if not data:
                    break
                
                command_parts = data.decode().split()
                command = command_parts[0].upper()

                if not authenticated:
                    if command == 'AUTH' and len(command_parts) == 3:
                        username = command_parts[1]
                        password = command_parts[2]
                        if self.authenticate(username, password):
                            conn.sendall(b"OK")
                            authenticated = True
                        else:
                            conn.sendall(b"ERROR: Authentication failed")
                    elif command == 'REGISTER' and len(command_parts) == 3:
                        username = command_parts[1]
                        password = command_parts[2]
                        result = self.register_user(username, password)
                        conn.sendall(result.encode())
                    else:
                        conn.sendall(b"ERROR: Authentication required")
                else:
                    if command == "PUT" and len(command_parts) == 4:
                        key, data_type, data_size = command_parts[1:]
                        data = conn.recv(int(data_size))
                        result = self.put(key, data_type, data, username)
                        conn.sendall(result.encode())
                    elif command == "GET" and len(command_parts) == 2:
                        key = command_parts[1]
                        data_type, data_size, data = self.get(key, username)
                        if data_type == "ERROR":
                            conn.sendall(b"ERROR")
                        else:
                            response = f"{data_type} {data_size} ".encode() + data
                            conn.sendall(response)
                    elif command == "DELETE" and len(command_parts) == 2:
                        key = command_parts[1]
                        result = self.delete(key, username)
                        conn.sendall(result.encode())
                    elif command == "LIST" and len(command_parts) == 1:
                        result = self.list(username)
                        conn.sendall(json.dumps(result).encode())
                    elif command == "BACKUP" and len(command_parts) == 1:
                        if self.check_permission(username, "*", "admin"):
                            backup_path = self.create_backup()
                            conn.sendall(backup_path.encode())
                        else:
                            conn.sendall(b"ERROR: Permission denied")
                    elif command == "RESTORE" and len(command_parts) == 2:
                        if self.check_permission(username, "*", "admin"):
                            backup_path = command_parts[1]
                            result = self.restore_backup(backup_path)
                            conn.sendall(result.encode())
                        else:
                            conn.sendall(b"ERROR: Permission denied")
                    elif command == "FILELIST" and len(command_parts) == 1:
                        """返回文件列表，包含類型信息"""
                        result = []
                        for key, info in self.index.items():
                            if self.check_permission(username, key, "read"):
                                result.append({
                                    "key": key,
                                    "type": info["type"],
                                    "size": info.get("original_size", 0),
                                    "last_modified": info.get("last_modified", "")
                                })
                        conn.sendall(json.dumps(result).encode())
                    else:
                        conn.sendall(b"ERROR: Invalid command")
        except Exception as e:
            logging.error(f"Error handling client {addr}: {str(e)}")
            print(f"Error: {e}")
        finally:
            conn.close()
            self.connection_count -= 1
            print(f"Connection from {addr} closed")

    def run(self, host, port):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            # 設置 socket 選項，允許地址重用
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind((host, port))
            s.listen()
            print(f"Server listening on {host}:{port}")
            logging.info(f"Server started on {host}:{port}")
            
            while True:
                conn, addr = s.accept()
                self.connection_pool.submit(self.handle_client, conn, addr)

# Example Usage
if __name__ == "__main__":
    db = OmniDB(
        data_dir="data",
        index_file="index.json",
        users_file="users.json",
        backup_dir="backups",
        log_file="server.log",
        max_connections=100,
        rate_limit=100,
        compression=True,
        encryption=True
    )
    # 使用端口 65434
    db.run("127.0.0.1", 65434) 