import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import os
import shutil
import json
import datetime
from cryptography.fernet import Fernet

class KeyManager:
    """加密金鑰管理工具，提供備份、恢復和重新生成金鑰的功能"""
    
    def __init__(self, key_file="encryption.key", key_backup_dir="key_backups"):
        self.key_file = key_file
        self.key_backup_dir = key_backup_dir
        os.makedirs(self.key_backup_dir, exist_ok=True)
    
    def backup_key(self):
        """備份當前的加密金鑰"""
        if not os.path.exists(self.key_file):
            return "ERROR: 找不到加密金鑰文件"
            
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_file = os.path.join(self.key_backup_dir, f"encryption_key_{timestamp}.bak")
        
        try:
            shutil.copy2(self.key_file, backup_file)
            
            # 記錄備份信息
            backup_info_file = os.path.join(self.key_backup_dir, "backup_info.json")
            backup_info = {}
            if os.path.exists(backup_info_file):
                with open(backup_info_file, "r") as f:
                    backup_info = json.load(f)
            
            backup_info[timestamp] = {
                "file": backup_file,
                "timestamp": timestamp,
                "datetime": datetime.datetime.now().isoformat(),
                "original_file": self.key_file
            }
            
            with open(backup_info_file, "w") as f:
                json.dump(backup_info, f, indent=4)
                
            return f"SUCCESS: 金鑰已備份到 {backup_file}"
        except Exception as e:
            return f"ERROR: 備份金鑰失敗 - {str(e)}"
    
    def restore_key(self, backup_timestamp=None):
        """從備份恢復加密金鑰，如果沒有指定，使用最新的備份"""
        backup_info_file = os.path.join(self.key_backup_dir, "backup_info.json")
        if not os.path.exists(backup_info_file):
            return "ERROR: 找不到備份信息文件"
        
        with open(backup_info_file, "r") as f:
            backup_info = json.load(f)
        
        if not backup_info:
            return "ERROR: 沒有可用的金鑰備份"
        
        if backup_timestamp:
            if backup_timestamp not in backup_info:
                return f"ERROR: 找不到時間戳為 {backup_timestamp} 的備份"
            backup_file = backup_info[backup_timestamp]["file"]
        else:
            # 使用最新的備份
            latest_timestamp = max(backup_info.keys())
            backup_file = backup_info[latest_timestamp]["file"]
            backup_timestamp = latest_timestamp
        
        # 先備份當前金鑰
        current_backup = self.backup_key()
        if current_backup.startswith("ERROR"):
            return f"WARNING: 無法備份當前金鑰 - {current_backup}，將直接恢復"
        
        try:
            shutil.copy2(backup_file, self.key_file)
            return f"SUCCESS: 已從 {backup_timestamp} 的備份恢復金鑰"
        except Exception as e:
            return f"ERROR: 恢復金鑰失敗 - {str(e)}"
    
    def generate_new_key(self, backup_current=True):
        """生成新的加密金鑰，可選擇是否備份當前金鑰"""
        if backup_current and os.path.exists(self.key_file):
            backup_result = self.backup_key()
            if backup_result.startswith("ERROR"):
                return f"WARNING: 無法備份當前金鑰 - {backup_result}，將直接生成新金鑰"
        
        try:
            key = Fernet.generate_key()
            with open(self.key_file, "wb") as f:
                f.write(key)
            return f"SUCCESS: 已生成新的加密金鑰"
        except Exception as e:
            return f"ERROR: 生成新金鑰失敗 - {str(e)}"
    
    def get_backup_list(self):
        """獲取所有金鑰備份的列表"""
        backup_info_file = os.path.join(self.key_backup_dir, "backup_info.json")
        if not os.path.exists(backup_info_file):
            return []
        
        with open(backup_info_file, "r") as f:
            backup_info = json.load(f)
        
        result = []
        for timestamp, info in sorted(backup_info.items(), reverse=True):
            result.append({
                "timestamp": timestamp,
                "datetime": info["datetime"],
                "file": info["file"]
            })
        
        return result
    
    def get_current_key(self):
        """獲取當前加密金鑰（僅用於校驗，不應該暴露）"""
        if not os.path.exists(self.key_file):
            return None
        
        try:
            with open(self.key_file, "rb") as f:
                key = f.read()
            return key
        except Exception as e:
            print(f"讀取金鑰失敗: {e}")
            return None

class KeyManagerApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("OmniDB 金鑰管理工具")
        self.geometry("700x500")
        self.key_manager = KeyManager()
        
        # 創建主界面
        self.create_widgets()
    
    def create_widgets(self):
        # 主框架
        main_frame = ttk.Frame(self)
        main_frame.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)
        
        # 左側面板 - 操作按鈕
        left_panel = ttk.LabelFrame(main_frame, text="金鑰操作")
        left_panel.pack(side=tk.LEFT, padx=5, pady=5, fill=tk.Y)
        
        # 當前金鑰狀態
        key_status_frame = ttk.Frame(left_panel)
        key_status_frame.pack(padx=5, pady=5, fill=tk.X)
        
        self.key_status_var = tk.StringVar(value="未檢查")
        key_status_label = ttk.Label(key_status_frame, text="當前金鑰狀態:")
        key_status_label.grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        
        key_status_value = ttk.Label(key_status_frame, textvariable=self.key_status_var)
        key_status_value.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)
        
        check_key_button = ttk.Button(key_status_frame, text="檢查", command=self.check_current_key)
        check_key_button.grid(row=0, column=2, padx=5, pady=5, sticky=tk.W)
        
        # 備份按鈕
        backup_button = ttk.Button(left_panel, text="備份當前金鑰", command=self.backup_key)
        backup_button.pack(padx=5, pady=10, fill=tk.X)
        
        # 恢復按鈕
        restore_button = ttk.Button(left_panel, text="恢復選擇的備份", command=self.restore_key)
        restore_button.pack(padx=5, pady=10, fill=tk.X)
        
        # 生成新金鑰按鈕
        generate_button = ttk.Button(left_panel, text="生成新金鑰", command=self.generate_new_key)
        generate_button.pack(padx=5, pady=10, fill=tk.X)
        
        # 刷新列表按鈕
        refresh_button = ttk.Button(left_panel, text="刷新備份列表", command=self.refresh_backup_list)
        refresh_button.pack(padx=5, pady=10, fill=tk.X)
        
        # 右側面板 - 備份列表
        right_panel = ttk.LabelFrame(main_frame, text="金鑰備份列表")
        right_panel.pack(side=tk.RIGHT, padx=5, pady=5, fill=tk.BOTH, expand=True)
        
        # 備份列表
        self.backup_list = ttk.Treeview(right_panel, columns=("timestamp", "datetime", "file"), show="headings")
        self.backup_list.heading("timestamp", text="備份ID")
        self.backup_list.heading("datetime", text="日期時間")
        self.backup_list.heading("file", text="文件路徑")
        
        self.backup_list.column("timestamp", width=100)
        self.backup_list.column("datetime", width=150)
        self.backup_list.column("file", width=250)
        
        self.backup_list.pack(padx=5, pady=5, fill=tk.BOTH, expand=True)
        
        # 日誌區域
        log_frame = ttk.LabelFrame(self, text="操作日誌")
        log_frame.pack(padx=10, pady=10, fill=tk.X)
        
        self.log_text = scrolledtext.ScrolledText(log_frame, height=8)
        self.log_text.pack(padx=5, pady=5, fill=tk.BOTH, expand=True)
        
        # 初始刷新備份列表
        self.refresh_backup_list()
        
        # 初始檢查金鑰
        self.check_current_key()
    
    def log(self, message):
        """添加日誌訊息"""
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.log_text.insert(tk.END, f"[{timestamp}] {message}\n")
        self.log_text.see(tk.END)
    
    def check_current_key(self):
        """檢查當前金鑰狀態"""
        key = self.key_manager.get_current_key()
        if key:
            self.key_status_var.set("已存在")
            self.log("金鑰檢查: 當前金鑰存在")
        else:
            self.key_status_var.set("不存在")
            self.log("金鑰檢查: 當前金鑰不存在")
    
    def backup_key(self):
        """備份當前金鑰"""
        result = self.key_manager.backup_key()
        self.log(result)
        if result.startswith("SUCCESS"):
            messagebox.showinfo("備份成功", result)
            self.refresh_backup_list()
        else:
            messagebox.showerror("備份失敗", result)
    
    def restore_key(self):
        """從選擇的備份恢復金鑰"""
        selected = self.backup_list.selection()
        if not selected:
            messagebox.showerror("錯誤", "請先選擇一個備份")
            return
        
        timestamp = self.backup_list.item(selected[0])["values"][0]
        
        if messagebox.askyesno("確認恢復", f"確定要從 {timestamp} 的備份恢復金鑰嗎？\n這將覆蓋當前金鑰。"):
            result = self.key_manager.restore_key(timestamp)
            self.log(result)
            if result.startswith("SUCCESS"):
                messagebox.showinfo("恢復成功", result)
                self.check_current_key()
            else:
                messagebox.showerror("恢復失敗", result)
    
    def generate_new_key(self):
        """生成新的加密金鑰"""
        if messagebox.askyesno("確認生成", "確定要生成新的加密金鑰嗎？\n這將使用新金鑰替換當前金鑰。\n注意：新金鑰將無法解密之前加密的數據！"):
            result = self.key_manager.generate_new_key()
            self.log(result)
            if result.startswith("SUCCESS"):
                messagebox.showinfo("生成成功", result)
                self.check_current_key()
                self.refresh_backup_list()
            else:
                messagebox.showerror("生成失敗", result)
    
    def refresh_backup_list(self):
        """刷新備份列表"""
        # 清空列表
        for item in self.backup_list.get_children():
            self.backup_list.delete(item)
        
        # 獲取備份列表
        backups = self.key_manager.get_backup_list()
        
        if not backups:
            self.log("備份列表為空")
        else:
            # 填充列表
            for backup in backups:
                self.backup_list.insert("", tk.END, values=(
                    backup["timestamp"],
                    backup["datetime"],
                    backup["file"]
                ))
            self.log(f"已刷新備份列表，共 {len(backups)} 個備份")

if __name__ == "__main__":
    app = KeyManagerApp()
    app.mainloop() 