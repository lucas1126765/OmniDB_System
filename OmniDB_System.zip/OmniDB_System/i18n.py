"""
多語言支持模塊
"""

class I18n:
    def __init__(self, language="en"):
        self.language = language
        self.translations = {
            "en": {
                # 通用
                "ok": "OK",
                "error": "Error",
                "success": "Success",
                "warning": "Warning",
                "cancel": "Cancel",
                "confirm": "Confirm",
                
                # 連接頁面
                "server_connection": "Server Connection",
                "host": "Host:",
                "port": "Port:",
                "connect": "Connect",
                "connection_success": "Successfully connected to {}:{}",
                "connection_error": "Failed to connect to server",
                
                # 認證
                "authentication": "Authentication",
                "username": "Username:",
                "password": "Password:",
                "login": "Login",
                "login_success": "Successfully logged in as {}",
                "login_failed": "Failed to authenticate",
                "auth_required": "Authentication required",
                
                # 註冊功能
                "register": "Register",
                "register_tab": "Register",
                "registration": "User Registration",
                "confirm_password": "Confirm Password:",
                "register_btn": "Register New User",
                "register_success": "Successfully registered user: {}",
                "register_failed": "Failed to register user",
                "passwords_not_match": "Passwords do not match",
                "user_exists": "User already exists",
                "register_first": "Please register first to use the system",
                
                # 管理員用戶
                "create_admin": "Create Admin User",
                "create_admin_btn": "Create Default Admin User",
                "admin_created": "Default admin user created with full permissions",
                "admin_create_failed": "Could not create default user: {}",
                "admin_desc": "Creates admin:admin user with full permissions",
                
                # 數據管理
                "data_management": "Data Management",
                "available_keys": "Available Keys",
                "key_name": "Key Name",
                "refresh_list": "Refresh List",
                "delete_selected": "Delete Selected",
                "key": "Key:",
                "data_type": "Data Type:",
                "data_content": "Data Content",
                "get_data": "Get Data",
                "put_data": "Put Data",
                "clear": "Clear",
                "key_empty_error": "Key cannot be empty",
                "get_data_failed": "Failed to get data",
                "binary_data": "Binary data ({} bytes)",
                "data_stored": "Data stored with key: {}",
                "store_failed": "Failed to store data: {}",
                "no_key_selected": "No key selected",
                "confirm_delete": "Are you sure you want to delete key: {}?",
                "key_deleted": "Key deleted: {}",
                "delete_failed": "Failed to delete key: {}",
                
                # 備份與還原
                "backup_restore": "Backup & Restore",
                "create_backup": "Create Backup",
                "create_backup_btn": "Create Backup",
                "no_backup": "No backup created yet",
                "backup_error": "Backup Error",
                "backup_created": "Backup created at: {}",
                "last_backup": "Last backup: {}",
                "restore_from": "Restore from Backup",
                "backup_path": "Backup Path:",
                "browse": "Browse",
                "restore_btn": "Restore Backup",
                "backup_log": "Backup & Restore Log",
                "backup_path_empty": "Backup path cannot be empty",
                "confirm_restore": "Are you sure you want to restore from backup? This will overwrite any existing data.",
                "restore_success": "Successfully restored from backup",
                "restore_error": "Restore Error",
                
                # 標籤頁
                "login_tab": "Login",
                "data_tab": "Data Management",
                "backup_tab": "Backup & Restore",
                
                # 狀態
                "disconnected": "Disconnected",
                "connected": "Connected to {}:{}",
                "logged_in": "Logged in as {}",
                
                # 金鑰管理
                "key_management": "Key Management",
                "key_operations": "Key Operations",
                "current_key_status": "Current Key Status:",
                "check": "Check",
                "backup_current_key": "Backup Current Key",
                "restore_selected_backup": "Restore Selected Backup",
                "generate_new_key": "Generate New Key",
                "refresh_backup_list": "Refresh Backup List",
                "key_backup_list": "Key Backup List",
                "backup_id": "Backup ID",
                "datetime": "Date/Time",
                "file_path": "File Path",
                "operation_log": "Operation Log",
                "key_exists": "Exists",
                "key_not_exists": "Not Exists",
                "key_check": "Key check: Current key exists",
                "key_check_not": "Key check: Current key does not exist",
                "backup_empty": "Backup list is empty",
                "backup_refreshed": "Refreshed backup list, total {} backups",
                "backup_success": "Key has been backed up to {}",
                "backup_failed": "Failed to backup key - {}",
                "restore_success": "Successfully restored from backup {}",
                "restore_failed": "Failed to restore key - {}",
                "restore_confirm": "Are you sure to restore key from backup {}?\nThis will overwrite current key.",
                "generate_confirm": "Are you sure to generate a new key?\nThis will replace current key.\nNote: New key will not be able to decrypt previously encrypted data!",
                "generate_success": "Successfully generated new key",
                "generate_failed": "Failed to generate new key - {}",
                "select_backup": "Please select a backup first",
                
                # 檔案上傳
                "file_upload": "File Upload",
                "upload_file": "Upload File",
                "key_name": "Key Name:",
                "file_path_label": "File Path:",
                "browse": "Browse",
                "upload_button": "Upload File",
                "uploaded_files": "Uploaded Files",
                "file_key": "Key",
                "file_type": "Type",
                "file_size": "Size",
                "refresh_list": "Refresh List",
                "download_selected": "Download Selected File",
                "delete_selected_file": "Delete Selected File",
                "select_file": "Please select a file",
                "file_uploaded": "File uploaded, key: {}",
                "upload_failed": "Upload failed",
                "download_success": "File saved to: {}",
                "download_failed": "Failed to save file",
                "delete_confirm": "Are you sure to delete file {}?",
                "file_deleted": "File deleted: {}",
                "delete_failed": "Failed to delete file",
                "enter_key": "Please enter key name",
                "select_valid_file": "Please select a valid file",
                "login_first": "Please login first",
                "bytes": "{} bytes"
            },
            "zh": {
                # 通用
                "ok": "確定",
                "error": "錯誤",
                "success": "成功",
                "warning": "警告",
                "cancel": "取消",
                "confirm": "確認",
                
                # 連接頁面
                "server_connection": "伺服器連接",
                "host": "主機:",
                "port": "埠:",
                "connect": "連接",
                "connection_success": "成功連接到 {}:{}",
                "connection_error": "無法連接到伺服器",
                
                # 認證
                "authentication": "身份驗證",
                "username": "用戶名:",
                "password": "密碼:",
                "login": "登入",
                "login_success": "已成功以 {} 身份登入",
                "login_failed": "身份驗證失敗",
                "auth_required": "需要身份驗證",
                
                # 註冊功能
                "register": "註冊",
                "register_tab": "註冊",
                "registration": "用戶註冊",
                "confirm_password": "確認密碼:",
                "register_btn": "註冊新用戶",
                "register_success": "成功註冊用戶: {}",
                "register_failed": "註冊用戶失敗",
                "passwords_not_match": "密碼不匹配",
                "user_exists": "用戶已存在",
                "register_first": "請先註冊才能使用系統",
                
                # 管理員用戶
                "create_admin": "創建管理員用戶",
                "create_admin_btn": "創建默認管理員用戶",
                "admin_created": "已創建具有完全權限的默認管理員用戶",
                "admin_create_failed": "無法創建默認用戶: {}",
                "admin_desc": "創建用戶名/密碼為 admin:admin 的管理員用戶，具有完全權限",
                
                # 數據管理
                "data_management": "數據管理",
                "available_keys": "可用金鑰",
                "key_name": "金鑰名稱",
                "refresh_list": "刷新列表",
                "delete_selected": "刪除所選",
                "key": "金鑰:",
                "data_type": "數據類型:",
                "data_content": "數據內容",
                "get_data": "獲取數據",
                "put_data": "儲存數據",
                "clear": "清除",
                "key_empty_error": "金鑰不能為空",
                "get_data_failed": "獲取數據失敗",
                "binary_data": "二進制數據 ({} 字節)",
                "data_stored": "數據已儲存，金鑰為: {}",
                "store_failed": "儲存數據失敗: {}",
                "no_key_selected": "未選擇金鑰",
                "confirm_delete": "確定要刪除金鑰: {}?",
                "key_deleted": "已刪除金鑰: {}",
                "delete_failed": "刪除金鑰失敗: {}",
                
                # 備份與還原
                "backup_restore": "備份與還原",
                "create_backup": "創建備份",
                "create_backup_btn": "創建備份",
                "no_backup": "尚未創建備份",
                "backup_error": "備份錯誤",
                "backup_created": "已在 {} 創建備份",
                "last_backup": "最近備份: {}",
                "restore_from": "從備份還原",
                "backup_path": "備份路徑:",
                "browse": "瀏覽",
                "restore_btn": "還原備份",
                "backup_log": "備份與還原日誌",
                "backup_path_empty": "備份路徑不能為空",
                "confirm_restore": "確定要從備份還原嗎？這將覆蓋所有現有數據。",
                "restore_success": "已成功從備份還原",
                "restore_error": "還原錯誤",
                
                # 標籤頁
                "login_tab": "登入",
                "data_tab": "數據管理",
                "backup_tab": "備份與還原",
                
                # 狀態
                "disconnected": "未連接",
                "connected": "已連接到 {}:{}",
                "logged_in": "已以 {} 身份登入",
                
                # 金鑰管理
                "key_management": "金鑰管理",
                "key_operations": "金鑰操作",
                "current_key_status": "當前金鑰狀態:",
                "check": "檢查",
                "backup_current_key": "備份當前金鑰",
                "restore_selected_backup": "恢復選擇的備份",
                "generate_new_key": "生成新金鑰",
                "refresh_backup_list": "刷新備份列表",
                "key_backup_list": "金鑰備份列表",
                "backup_id": "備份ID",
                "datetime": "日期時間",
                "file_path": "文件路徑",
                "operation_log": "操作日誌",
                "key_exists": "已存在",
                "key_not_exists": "不存在",
                "key_check": "金鑰檢查: 當前金鑰存在",
                "key_check_not": "金鑰檢查: 當前金鑰不存在",
                "backup_empty": "備份列表為空",
                "backup_refreshed": "已刷新備份列表，共 {} 個備份",
                "backup_success": "金鑰已備份到 {}",
                "backup_failed": "備份金鑰失敗 - {}",
                "restore_success": "已從 {} 的備份恢復金鑰",
                "restore_failed": "恢復金鑰失敗 - {}",
                "restore_confirm": "確定要從 {} 的備份恢復金鑰嗎？\n這將覆蓋當前金鑰。",
                "generate_confirm": "確定要生成新的加密金鑰嗎？\n這將使用新金鑰替換當前金鑰。\n注意：新金鑰將無法解密之前加密的數據！",
                "generate_success": "已生成新的加密金鑰",
                "generate_failed": "生成新金鑰失敗 - {}",
                "select_backup": "請先選擇一個備份",
                
                # 檔案上傳
                "file_upload": "文件上傳",
                "upload_file": "上傳文件",
                "key_name": "金鑰名稱:",
                "file_path_label": "文件路徑:",
                "browse": "瀏覽",
                "upload_button": "上傳文件",
                "uploaded_files": "已上傳文件",
                "file_key": "金鑰",
                "file_type": "類型",
                "file_size": "大小",
                "refresh_list": "刷新列表",
                "download_selected": "下載選擇的文件",
                "delete_selected_file": "刪除選擇的文件",
                "select_file": "請先選擇一個文件",
                "file_uploaded": "文件已上傳，金鑰為: {}",
                "upload_failed": "上傳失敗",
                "download_success": "文件已保存到: {}",
                "download_failed": "保存文件失敗",
                "delete_confirm": "確定要刪除文件 {} 嗎？",
                "file_deleted": "文件已刪除: {}",
                "delete_failed": "刪除失敗",
                "enter_key": "請輸入金鑰名稱",
                "select_valid_file": "請選擇有效的文件",
                "login_first": "請先登入",
                "bytes": "{} 字節"
            }
        }
    
    def set_language(self, language):
        """設置當前語言"""
        if language in self.translations:
            self.language = language
    
    def get(self, key, *args):
        """獲取指定鍵的翻譯文本"""
        if self.language in self.translations and key in self.translations[self.language]:
            text = self.translations[self.language][key]
            if args:
                return text.format(*args)
            return text
        # 如果找不到翻譯，返回英文版本
        if "en" in self.translations and key in self.translations["en"]:
            text = self.translations["en"][key]
            if args:
                return text.format(*args)
            return text
        # 如果英文也找不到，返回鍵名
        return key 