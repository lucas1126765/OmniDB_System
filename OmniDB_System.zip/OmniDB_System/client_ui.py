import tkinter as tk
from tkinter import ttk, messagebox, filedialog, scrolledtext
import socket
import threading
import json
import os
import time
import shutil
import datetime
from i18n import I18n
from cryptography.fernet import Fernet

class KeyManager:
    """加密金鑰管理工具，提供備份、恢復和重新生成金鑰的功能"""
    
    def __init__(self, key_file="encryption.key", key_backup_dir="key_backups"):
        self.key_file = key_file
        self.key_backup_dir = key_backup_dir
        os.makedirs(self.key_backup_dir, exist_ok=True)
    
    def backup_key(self):
        """備份當前的加密金鑰"""
        if not os.path.exists(self.key_file):
            return "ERROR: 找不到加密金鑰文件"
            
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_file = os.path.join(self.key_backup_dir, f"encryption_key_{timestamp}.bak")
        
        try:
            shutil.copy2(self.key_file, backup_file)
            
            # 記錄備份信息
            backup_info_file = os.path.join(self.key_backup_dir, "backup_info.json")
            backup_info = {}
            if os.path.exists(backup_info_file):
                with open(backup_info_file, "r") as f:
                    backup_info = json.load(f)
            
            backup_info[timestamp] = {
                "file": backup_file,
                "timestamp": timestamp,
                "datetime": datetime.datetime.now().isoformat(),
                "original_file": self.key_file
            }
            
            with open(backup_info_file, "w") as f:
                json.dump(backup_info, f, indent=4)
                
            return f"SUCCESS: 金鑰已備份到 {backup_file}"
        except Exception as e:
            return f"ERROR: 備份金鑰失敗 - {str(e)}"
    
    def restore_key(self, backup_timestamp=None):
        """從備份恢復加密金鑰，如果沒有指定，使用最新的備份"""
        backup_info_file = os.path.join(self.key_backup_dir, "backup_info.json")
        if not os.path.exists(backup_info_file):
            return "ERROR: 找不到備份信息文件"
        
        with open(backup_info_file, "r") as f:
            backup_info = json.load(f)
        
        if not backup_info:
            return "ERROR: 沒有可用的金鑰備份"
        
        if backup_timestamp:
            if backup_timestamp not in backup_info:
                return f"ERROR: 找不到時間戳為 {backup_timestamp} 的備份"
            backup_file = backup_info[backup_timestamp]["file"]
        else:
            # 使用最新的備份
            latest_timestamp = max(backup_info.keys())
            backup_file = backup_info[latest_timestamp]["file"]
            backup_timestamp = latest_timestamp
        
        # 先備份當前金鑰
        current_backup = self.backup_key()
        if current_backup.startswith("ERROR"):
            return f"WARNING: 無法備份當前金鑰 - {current_backup}，將直接恢復"
        
        try:
            shutil.copy2(backup_file, self.key_file)
            return f"SUCCESS: 已從 {backup_timestamp} 的備份恢復金鑰"
        except Exception as e:
            return f"ERROR: 恢復金鑰失敗 - {str(e)}"
    
    def generate_new_key(self, backup_current=True):
        """生成新的加密金鑰，可選擇是否備份當前金鑰"""
        if backup_current and os.path.exists(self.key_file):
            backup_result = self.backup_key()
            if backup_result.startswith("ERROR"):
                return f"WARNING: 無法備份當前金鑰 - {backup_result}，將直接生成新金鑰"
        
        try:
            key = Fernet.generate_key()
            with open(self.key_file, "wb") as f:
                f.write(key)
            return f"SUCCESS: 已生成新的加密金鑰"
        except Exception as e:
            return f"ERROR: 生成新金鑰失敗 - {str(e)}"
    
    def get_backup_list(self):
        """獲取所有金鑰備份的列表"""
        backup_info_file = os.path.join(self.key_backup_dir, "backup_info.json")
        if not os.path.exists(backup_info_file):
            return []
        
        with open(backup_info_file, "r") as f:
            backup_info = json.load(f)
        
        result = []
        for timestamp, info in sorted(backup_info.items(), reverse=True):
            result.append({
                "timestamp": timestamp,
                "datetime": info["datetime"],
                "file": info["file"]
            })
        
        return result
    
    def get_current_key(self):
        """獲取當前加密金鑰（僅用於校驗，不應該暴露）"""
        if not os.path.exists(self.key_file):
            return None
        
        try:
            with open(self.key_file, "rb") as f:
                key = f.read()
            return key
        except Exception as e:
            print(f"讀取金鑰失敗: {e}")
            return None

class OmniDBClient:
    def __init__(self, host="127.0.0.1", port=65434):
        self.host = host
        self.port = port
        self.socket = None
        self.authenticated = False
        self.username = ""
        
    def connect(self):
        try:
            # 確保先關閉任何現有連接
            if self.socket:
                try:
                    self.socket.close()
                except:
                    pass
                self.socket = None
            
            # 創建新的 socket 連接
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.settimeout(5)  # 設置5秒超時
            self.socket.connect((self.host, self.port))
            return True
        except Exception as e:
            print(f"Connection error: {e}")
            if self.socket:
                try:
                    self.socket.close()
                except:
                    pass
                self.socket = None
            return False
    
    def close(self):
        if self.socket:
            try:
                self.socket.close()
            except Exception as e:
                print(f"Error closing socket: {e}")
            finally:
                self.socket = None
                self.authenticated = False
    
    def authenticate(self, username, password):
        if not self.socket:
            if not self.connect():
                return False
        
        try:
            auth_command = f"AUTH {username} {password}"
            self.socket.sendall(auth_command.encode())
            response = self.socket.recv(1024).decode()
            
            if response == "OK":
                self.authenticated = True
                self.username = username
                return True
            return False
        except Exception as e:
            print(f"Authentication error: {e}")
            self.close()  # 關閉連接並重置狀態
            return False
    
    def put(self, key, data_type, data):
        if not self.socket or not self.authenticated:
            return "ERROR: Not authenticated"
        
        try:
            command = f"PUT {key} {data_type} {len(data)}"
            self.socket.sendall(command.encode())
            time.sleep(0.1)  # Small delay to ensure command is processed
            self.socket.sendall(data)
            response = self.socket.recv(1024).decode()
            return response
        except Exception as e:
            print(f"PUT error: {e}")
            self.close()  # 關閉損壞的連接
            return f"ERROR: {str(e)}"
    
    def get(self, key):
        if not self.socket or not self.authenticated:
            return "ERROR", 0, b""
        
        try:
            command = f"GET {key}"
            self.socket.sendall(command.encode())
            response = self.socket.recv(4096)
            
            if response.startswith(b"ERROR"):
                return "ERROR", 0, b""
            
            # Parse response parts
            parts = response.split(b" ", 2)
            if len(parts) >= 3:
                data_type = parts[0].decode()
                data_size = int(parts[1].decode())
                data = parts[2]
                return data_type, data_size, data
            return "ERROR", 0, b""
        except Exception as e:
            print(f"GET error: {e}")
            self.close()  # 關閉損壞的連接
            return "ERROR", 0, b""
    
    def delete(self, key):
        if not self.socket or not self.authenticated:
            return "ERROR: Not authenticated"
        
        try:
            command = f"DELETE {key}"
            self.socket.sendall(command.encode())
            response = self.socket.recv(1024).decode()
            return response
        except Exception as e:
            print(f"DELETE error: {e}")
            return f"ERROR: {str(e)}"
    
    def list_keys(self):
        if not self.socket or not self.authenticated:
            return []
        
        try:
            command = "LIST"
            self.socket.sendall(command.encode())
            response = self.socket.recv(4096).decode()
            return json.loads(response)
        except Exception as e:
            print(f"LIST error: {e}")
            return []
    
    def backup(self):
        if not self.socket or not self.authenticated:
            return "ERROR: Not authenticated"
        
        try:
            command = "BACKUP"
            self.socket.sendall(command.encode())
            response = self.socket.recv(1024).decode()
            return response
        except Exception as e:
            print(f"BACKUP error: {e}")
            return f"ERROR: {str(e)}"
    
    def restore(self, backup_path):
        if not self.socket or not self.authenticated:
            return "ERROR: Not authenticated"
        
        try:
            command = f"RESTORE {backup_path}"
            self.socket.sendall(command.encode())
            response = self.socket.recv(1024).decode()
            return response
        except Exception as e:
            print(f"RESTORE error: {e}")
            return f"ERROR: {str(e)}"
    
    def register(self, username, password):
        """註冊新用戶"""
        if not self.socket:
            return False
        
        try:
            register_command = f"REGISTER {username} {password}"
            self.socket.sendall(register_command.encode())
            response = self.socket.recv(1024).decode()
            
            if response == "OK":
                return True
            return False
        except Exception as e:
            print(f"Registration error: {e}")
            return False

    # 添加新方法以上傳各種類型文件
    def upload_file(self, key, file_path):
        """上傳文件到服務器"""
        if not self.socket or not self.authenticated:
            return "ERROR: Not authenticated"
        
        try:
            # 取得文件類型
            _, ext = os.path.splitext(file_path)
            ext = ext.lower()
            
            # 判斷文件類型
            if ext in ['.jpg', '.jpeg', '.png', '.gif', '.bmp']:
                data_type = "image"
            elif ext in ['.mp4', '.avi', '.mov', '.wmv', '.flv']:
                data_type = "video"
            elif ext in ['.mp3', '.wav', '.ogg', '.flac']:
                data_type = "audio"
            elif ext in ['.html', '.htm', '.css', '.js', '.py', '.java', '.c', '.cpp', '.cs']:
                data_type = "code"
            else:
                data_type = "binary"
            
            # 讀取文件
            with open(file_path, "rb") as f:
                data = f.read()
            
            # 上傳文件
            command = f"PUT {key} {data_type} {len(data)}"
            self.socket.sendall(command.encode())
            time.sleep(0.1)  # Small delay to ensure command is processed
            self.socket.sendall(data)
            response = self.socket.recv(1024).decode()
            return response
        except Exception as e:
            print(f"Upload error: {e}")
            self.close()  # 關閉損壞的連接
            return f"ERROR: {str(e)}"

class OmniDBApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("OmniDB Client")
        self.geometry("800x600")
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        
        # 初始化 i18n
        self.i18n = I18n()
        
        # 初始化客戶端
        self.client = OmniDBClient()
        
        # 初始化金鑰管理器
        self.key_manager = KeyManager()
        
        # 創建界面
        self.create_widgets()
        
        # 設置默認語言
        self.current_language = "en"
        self.update_ui_texts()
        
        # Set theme
        self.style = ttk.Style()
        self.style.theme_use("clam")
        self.style.configure("TButton", background="#4CAF50", foreground="black", font=("Arial", 10, "bold"))
        self.style.configure("TLabel", font=("Arial", 10))
        self.style.configure("TEntry", font=("Arial", 10))
        self.style.configure("Treeview", font=("Arial", 10), rowheight=25)
        self.style.configure("Treeview.Heading", font=("Arial", 10, "bold"))
        
    def create_widgets(self):
        # 創建主選單
        self.menu_bar = tk.Menu(self)
        self.config(menu=self.menu_bar)
        
        # 語言選單
        self.lang_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="Language", menu=self.lang_menu)
        self.lang_menu.add_command(label="English", command=lambda: self.change_language("en"))
        self.lang_menu.add_command(label="中文", command=lambda: self.change_language("zh"))
        
        # Create tabs
        self.tab_control = ttk.Notebook(self)
        
        self.login_tab = ttk.Frame(self.tab_control)
        self.register_tab = ttk.Frame(self.tab_control)
        self.data_tab = ttk.Frame(self.tab_control)
        self.backup_tab = ttk.Frame(self.tab_control)
        self.key_tab = ttk.Frame(self.tab_control)  # 添加金鑰管理標籤頁
        self.file_upload_tab = ttk.Frame(self.tab_control)  # 添加文件上傳標籤頁
        
        self.tab_control.add(self.login_tab, text=self.i18n.get("login_tab"))
        self.tab_control.add(self.register_tab, text=self.i18n.get("register_tab"))
        self.tab_control.add(self.data_tab, text=self.i18n.get("data_tab"))
        self.tab_control.add(self.backup_tab, text=self.i18n.get("backup_tab"))
        self.tab_control.add(self.key_tab, text="金鑰管理")
        self.tab_control.add(self.file_upload_tab, text="文件上傳")
        
        self.tab_control.pack(expand=1, fill="both")
        
        # Create login tab
        self.create_login_tab()
        
        # Create register tab
        self.create_register_tab()
        
        # Create data management tab
        self.create_data_tab()
        
        # Create backup tab
        self.create_backup_tab()
        
        # Create key management tab
        self.create_key_tab()
        
        # Create file upload tab
        self.create_file_upload_tab()
        
        # Status bar
        self.status_var = tk.StringVar()
        self.status_var.set(self.i18n.get("disconnected"))
        self.status_bar = ttk.Label(self, textvariable=self.status_var, relief=tk.SUNKEN, anchor=tk.W)
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)
    
    def change_language(self, lang):
        """切換語言並更新UI"""
        self.i18n.set_language(lang)
        
        # 更新所有UI文本
        self.update_ui_texts()
    
    def update_ui_texts(self):
        """更新所有UI文本"""
        # 更新主視窗標題
        self.title("OmniDB Client")
        
        # 更新標籤頁標題
        self.tab_control.tab(0, text=self.i18n.get("login_tab"))
        self.tab_control.tab(1, text=self.i18n.get("register_tab"))
        self.tab_control.tab(2, text=self.i18n.get("data_tab"))
        self.tab_control.tab(3, text=self.i18n.get("backup_tab"))
        self.tab_control.tab(4, text="金鑰管理")
        self.tab_control.tab(5, text="文件上傳")
        
        # 更新登入標籤頁
        self.login_frame.config(text=self.i18n.get("server_connection"))
        self.host_label.config(text=self.i18n.get("host"))
        self.port_label.config(text=self.i18n.get("port"))
        self.connect_button.config(text=self.i18n.get("connect"))
        
        self.auth_frame.config(text=self.i18n.get("authentication"))
        self.username_label.config(text=self.i18n.get("username"))
        self.password_label.config(text=self.i18n.get("password"))
        self.login_button.config(text=self.i18n.get("login"))
        
        self.create_user_frame.config(text=self.i18n.get("create_admin"))
        self.create_user_button.config(text=self.i18n.get("create_admin_btn"))
        self.create_user_desc.config(text=self.i18n.get("admin_desc"))
        
        # 更新註冊標籤頁
        self.register_frame.config(text=self.i18n.get("registration"))
        self.reg_username_label.config(text=self.i18n.get("username"))
        self.reg_password_label.config(text=self.i18n.get("password"))
        self.reg_confirm_label.config(text=self.i18n.get("confirm_password"))
        self.register_button.config(text=self.i18n.get("register_btn"))
        
        # 更新數據管理標籤頁
        self.left_panel.config(text=self.i18n.get("available_keys"))
        self.key_list.heading("key", text=self.i18n.get("key_name"))
        self.refresh_button.config(text=self.i18n.get("refresh_list"))
        self.delete_button.config(text=self.i18n.get("delete_selected"))
        
        self.right_panel.config(text=self.i18n.get("data_management"))
        self.key_label.config(text=self.i18n.get("key"))
        self.data_type_label.config(text=self.i18n.get("data_type"))
        self.content_frame.config(text=self.i18n.get("data_content"))
        self.get_button.config(text=self.i18n.get("get_data"))
        self.put_button.config(text=self.i18n.get("put_data"))
        self.clear_button.config(text=self.i18n.get("clear"))
        
        # 更新備份與還原標籤頁
        self.backup_section.config(text=self.i18n.get("create_backup"))
        self.backup_button.config(text=self.i18n.get("create_backup_btn"))
        if "No backup" in self.backup_result.cget("text"):
            self.backup_result.config(text=self.i18n.get("no_backup"))
        elif "Last backup" in self.backup_result.cget("text"):
            backup_path = self.backup_result.cget("text").split(": ", 1)[1]
            self.backup_result.config(text=self.i18n.get("last_backup", backup_path))
            
        self.restore_section.config(text=self.i18n.get("restore_from"))
        self.backup_path_label.config(text=self.i18n.get("backup_path"))
        self.browse_button.config(text=self.i18n.get("browse"))
        self.restore_button.config(text=self.i18n.get("restore_btn"))
        self.log_section.config(text=self.i18n.get("backup_log"))
        
        # 更新狀態欄
        if "Disconnected" in self.status_var.get():
            self.status_var.set(self.i18n.get("disconnected"))
        elif "Connected to" in self.status_var.get():
            parts = self.status_var.get().split(" ")
            host_port = parts[-1].split(":")
            self.status_var.set(self.i18n.get("connected", host_port[0], host_port[1]))
        elif "Logged in as" in self.status_var.get():
            username = self.status_var.get().split(" ")[-1]
            self.status_var.set(self.i18n.get("logged_in", username))
    
    def create_login_tab(self):
        self.login_frame = ttk.LabelFrame(self.login_tab, text=self.i18n.get("server_connection"))
        self.login_frame.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)
        
        # Server settings
        server_frame = ttk.Frame(self.login_frame)
        server_frame.pack(padx=10, pady=10, fill=tk.X)
        
        self.host_label = ttk.Label(server_frame, text=self.i18n.get("host"))
        self.host_label.grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        self.host_entry = ttk.Entry(server_frame)
        self.host_entry.insert(0, "127.0.0.1")
        self.host_entry.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)
        
        self.port_label = ttk.Label(server_frame, text=self.i18n.get("port"))
        self.port_label.grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
        self.port_entry = ttk.Entry(server_frame)
        self.port_entry.insert(0, "65434")
        self.port_entry.grid(row=1, column=1, padx=5, pady=5, sticky=tk.W)
        
        self.connect_button = ttk.Button(server_frame, text=self.i18n.get("connect"), command=self.connect_to_server)
        self.connect_button.grid(row=2, column=0, columnspan=2, padx=5, pady=10)
        
        # Authentication
        self.auth_frame = ttk.LabelFrame(self.login_frame, text=self.i18n.get("authentication"))
        self.auth_frame.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)
        
        self.username_label = ttk.Label(self.auth_frame, text=self.i18n.get("username"))
        self.username_label.grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        self.username_entry = ttk.Entry(self.auth_frame)
        self.username_entry.insert(0, "admin")
        self.username_entry.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)
        
        self.password_label = ttk.Label(self.auth_frame, text=self.i18n.get("password"))
        self.password_label.grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
        self.password_entry = ttk.Entry(self.auth_frame, show="*")
        self.password_entry.insert(0, "admin")
        self.password_entry.grid(row=1, column=1, padx=5, pady=5, sticky=tk.W)
        
        self.login_button = ttk.Button(self.auth_frame, text=self.i18n.get("login"), command=self.login)
        self.login_button.grid(row=2, column=0, columnspan=2, padx=5, pady=10)
        
        # Create a default user
        self.create_user_frame = ttk.LabelFrame(self.login_frame, text=self.i18n.get("create_admin"))
        self.create_user_frame.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)
        
        self.create_user_button = ttk.Button(self.create_user_frame, text=self.i18n.get("create_admin_btn"), 
                                            command=self.create_default_user)
        self.create_user_button.pack(padx=5, pady=10, fill=tk.X)
        
        self.create_user_desc = ttk.Label(self.create_user_frame, text=self.i18n.get("admin_desc"))
        self.create_user_desc.pack(pady=5)
    
    def create_register_tab(self):
        """創建註冊標籤頁"""
        self.register_frame = ttk.LabelFrame(self.register_tab, text=self.i18n.get("registration"))
        self.register_frame.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)
        
        register_form = ttk.Frame(self.register_frame)
        register_form.pack(padx=10, pady=10, fill=tk.X)
        
        # 用户名
        self.reg_username_label = ttk.Label(register_form, text=self.i18n.get("username"))
        self.reg_username_label.grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        self.reg_username_entry = ttk.Entry(register_form, width=30)
        self.reg_username_entry.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)
        
        # 密码
        self.reg_password_label = ttk.Label(register_form, text=self.i18n.get("password"))
        self.reg_password_label.grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
        self.reg_password_entry = ttk.Entry(register_form, show="*", width=30)
        self.reg_password_entry.grid(row=1, column=1, padx=5, pady=5, sticky=tk.W)
        
        # 确认密码
        self.reg_confirm_label = ttk.Label(register_form, text=self.i18n.get("confirm_password"))
        self.reg_confirm_label.grid(row=2, column=0, padx=5, pady=5, sticky=tk.W)
        self.reg_confirm_entry = ttk.Entry(register_form, show="*", width=30)
        self.reg_confirm_entry.grid(row=2, column=1, padx=5, pady=5, sticky=tk.W)
        
        # 註冊按鈕
        self.register_button = ttk.Button(register_form, text=self.i18n.get("register_btn"), 
                                        command=self.register_user)
        self.register_button.grid(row=3, column=0, columnspan=2, padx=5, pady=20)
    
    def create_data_tab(self):
        data_frame = ttk.Frame(self.data_tab)
        data_frame.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)
        
        # Left panel with key list
        self.left_panel = ttk.LabelFrame(data_frame, text=self.i18n.get("available_keys"))
        self.left_panel.pack(side=tk.LEFT, padx=5, pady=5, fill=tk.BOTH, expand=True)
        
        self.key_list = ttk.Treeview(self.left_panel, columns=("key",), show="headings")
        self.key_list.heading("key", text=self.i18n.get("key_name"))
        self.key_list.pack(padx=5, pady=5, fill=tk.BOTH, expand=True)
        
        button_frame = ttk.Frame(self.left_panel)
        button_frame.pack(padx=5, pady=5, fill=tk.X)
        
        self.refresh_button = ttk.Button(button_frame, text=self.i18n.get("refresh_list"), command=self.refresh_keys)
        self.refresh_button.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        self.delete_button = ttk.Button(button_frame, text=self.i18n.get("delete_selected"), command=self.delete_key)
        self.delete_button.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        # Right panel with data view/edit
        self.right_panel = ttk.LabelFrame(data_frame, text=self.i18n.get("data_management"))
        self.right_panel.pack(side=tk.RIGHT, padx=5, pady=5, fill=tk.BOTH, expand=True)
        
        # Key entry
        key_frame = ttk.Frame(self.right_panel)
        key_frame.pack(padx=5, pady=5, fill=tk.X)
        
        self.key_label = ttk.Label(key_frame, text=self.i18n.get("key"))
        self.key_label.pack(side=tk.LEFT, padx=5)
        self.key_entry = ttk.Entry(key_frame)
        self.key_entry.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        # Type selection
        type_frame = ttk.Frame(self.right_panel)
        type_frame.pack(padx=5, pady=5, fill=tk.X)
        
        self.data_type_label = ttk.Label(type_frame, text=self.i18n.get("data_type"))
        self.data_type_label.pack(side=tk.LEFT, padx=5)
        self.type_var = tk.StringVar(value="text")
        type_options = ttk.Combobox(type_frame, textvariable=self.type_var)
        type_options["values"] = ("text", "binary", "image", "json", "xml")
        type_options.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        # Data content
        self.content_frame = ttk.LabelFrame(self.right_panel, text=self.i18n.get("data_content"))
        self.content_frame.pack(padx=5, pady=5, fill=tk.BOTH, expand=True)
        
        self.data_text = scrolledtext.ScrolledText(self.content_frame)
        self.data_text.pack(padx=5, pady=5, fill=tk.BOTH, expand=True)
        
        # Action buttons
        action_frame = ttk.Frame(self.right_panel)
        action_frame.pack(padx=5, pady=5, fill=tk.X)
        
        self.get_button = ttk.Button(action_frame, text=self.i18n.get("get_data"), command=self.get_data)
        self.get_button.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        self.put_button = ttk.Button(action_frame, text=self.i18n.get("put_data"), command=self.put_data)
        self.put_button.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        self.clear_button = ttk.Button(action_frame, text=self.i18n.get("clear"), command=self.clear_data)
        self.clear_button.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        # Connect double-click on key list to get_data
        self.key_list.bind("<Double-1>", self.on_key_double_click)
    
    def create_backup_tab(self):
        backup_frame = ttk.Frame(self.backup_tab)
        backup_frame.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)
        
        # Backup section
        self.backup_section = ttk.LabelFrame(backup_frame, text=self.i18n.get("create_backup"))
        self.backup_section.pack(padx=5, pady=5, fill=tk.X)
        
        self.backup_button = ttk.Button(self.backup_section, text=self.i18n.get("create_backup_btn"), command=self.create_backup)
        self.backup_button.pack(padx=10, pady=10, fill=tk.X)
        
        self.backup_result = ttk.Label(self.backup_section, text=self.i18n.get("no_backup"))
        self.backup_result.pack(padx=10, pady=10, fill=tk.X)
        
        # Restore section
        self.restore_section = ttk.LabelFrame(backup_frame, text=self.i18n.get("restore_from"))
        self.restore_section.pack(padx=5, pady=5, fill=tk.X)
        
        restore_form = ttk.Frame(self.restore_section)
        restore_form.pack(padx=10, pady=10, fill=tk.X)
        
        self.backup_path_label = ttk.Label(restore_form, text=self.i18n.get("backup_path"))
        self.backup_path_label.pack(side=tk.LEFT, padx=5)
        self.restore_path = ttk.Entry(restore_form)
        self.restore_path.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        self.browse_button = ttk.Button(restore_form, text=self.i18n.get("browse"), command=self.browse_backup)
        self.browse_button.pack(side=tk.LEFT, padx=5)
        
        self.restore_button = ttk.Button(self.restore_section, text=self.i18n.get("restore_btn"), command=self.restore_backup)
        self.restore_button.pack(padx=10, pady=10, fill=tk.X)
        
        # Log section
        self.log_section = ttk.LabelFrame(backup_frame, text=self.i18n.get("backup_log"))
        self.log_section.pack(padx=5, pady=5, fill=tk.BOTH, expand=True)
        
        self.log_text = scrolledtext.ScrolledText(self.log_section)
        self.log_text.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)
    
    def create_key_tab(self):
        """創建金鑰管理標籤頁"""
        # 主框架
        main_frame = ttk.Frame(self.key_tab)
        main_frame.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)
        
        # 左側面板 - 操作按鈕
        left_panel = ttk.LabelFrame(main_frame, text="金鑰操作")
        left_panel.pack(side=tk.LEFT, padx=5, pady=5, fill=tk.Y)
        
        # 當前金鑰狀態
        key_status_frame = ttk.Frame(left_panel)
        key_status_frame.pack(padx=5, pady=5, fill=tk.X)
        
        self.key_status_var = tk.StringVar(value="未檢查")
        key_status_label = ttk.Label(key_status_frame, text="當前金鑰狀態:")
        key_status_label.grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        
        key_status_value = ttk.Label(key_status_frame, textvariable=self.key_status_var)
        key_status_value.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)
        
        check_key_button = ttk.Button(key_status_frame, text="檢查", command=self.check_current_key)
        check_key_button.grid(row=0, column=2, padx=5, pady=5, sticky=tk.W)
        
        # 備份按鈕
        backup_button = ttk.Button(left_panel, text="備份當前金鑰", command=self.backup_key)
        backup_button.pack(padx=5, pady=10, fill=tk.X)
        
        # 恢復按鈕
        restore_button = ttk.Button(left_panel, text="恢復選擇的備份", command=self.restore_key)
        restore_button.pack(padx=5, pady=10, fill=tk.X)
        
        # 生成新金鑰按鈕
        generate_button = ttk.Button(left_panel, text="生成新金鑰", command=self.generate_new_key)
        generate_button.pack(padx=5, pady=10, fill=tk.X)
        
        # 刷新列表按鈕
        refresh_button = ttk.Button(left_panel, text="刷新備份列表", command=self.refresh_backup_list)
        refresh_button.pack(padx=5, pady=10, fill=tk.X)
        
        # 右側面板 - 備份列表
        right_panel = ttk.LabelFrame(main_frame, text="金鑰備份列表")
        right_panel.pack(side=tk.RIGHT, padx=5, pady=5, fill=tk.BOTH, expand=True)
        
        # 備份列表
        self.backup_list = ttk.Treeview(right_panel, columns=("timestamp", "datetime", "file"), show="headings")
        self.backup_list.heading("timestamp", text="備份ID")
        self.backup_list.heading("datetime", text="日期時間")
        self.backup_list.heading("file", text="文件路徑")
        
        self.backup_list.column("timestamp", width=100)
        self.backup_list.column("datetime", width=150)
        self.backup_list.column("file", width=250)
        
        self.backup_list.pack(padx=5, pady=5, fill=tk.BOTH, expand=True)
        
        # 日誌區域
        log_frame = ttk.LabelFrame(self.key_tab, text="操作日誌")
        log_frame.pack(padx=10, pady=10, fill=tk.X)
        
        self.key_log_text = scrolledtext.ScrolledText(log_frame, height=8)
        self.key_log_text.pack(padx=5, pady=5, fill=tk.BOTH, expand=True)
        
        # 初始刷新備份列表
        self.refresh_backup_list()
        
        # 初始檢查金鑰
        self.check_current_key()
    
    def create_file_upload_tab(self):
        """創建文件上傳標籤頁"""
        main_frame = ttk.Frame(self.file_upload_tab)
        main_frame.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)
        
        # 上傳表單
        upload_frame = ttk.LabelFrame(main_frame, text="上傳文件")
        upload_frame.pack(padx=5, pady=5, fill=tk.X)
        
        form_frame = ttk.Frame(upload_frame)
        form_frame.pack(padx=10, pady=10, fill=tk.X)
        
        # 金鑰名稱
        ttk.Label(form_frame, text="金鑰名稱:").grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        self.upload_key_entry = ttk.Entry(form_frame, width=40)
        self.upload_key_entry.grid(row=0, column=1, padx=5, pady=5, sticky=tk.W)
        
        # 文件路徑
        ttk.Label(form_frame, text="文件路徑:").grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
        file_path_frame = ttk.Frame(form_frame)
        file_path_frame.grid(row=1, column=1, padx=5, pady=5, sticky=tk.W)
        
        self.file_path_entry = ttk.Entry(file_path_frame, width=30)
        self.file_path_entry.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        browse_button = ttk.Button(file_path_frame, text="瀏覽", command=self.browse_file)
        browse_button.pack(side=tk.LEFT, padx=5)
        
        # 上傳按鈕
        upload_button = ttk.Button(form_frame, text="上傳文件", command=self.upload_file)
        upload_button.grid(row=2, column=0, columnspan=2, padx=5, pady=10)
        
        # 文件列表
        list_frame = ttk.LabelFrame(main_frame, text="已上傳文件")
        list_frame.pack(padx=5, pady=5, fill=tk.BOTH, expand=True)
        
        # 文件列表
        self.file_list = ttk.Treeview(list_frame, columns=("key", "type", "size"), show="headings")
        self.file_list.heading("key", text="金鑰")
        self.file_list.heading("type", text="類型")
        self.file_list.heading("size", text="大小")
        
        self.file_list.column("key", width=200)
        self.file_list.column("type", width=100)
        self.file_list.column("size", width=100)
        
        self.file_list.pack(padx=5, pady=5, fill=tk.BOTH, expand=True)
        
        # 按鈕區域
        button_frame = ttk.Frame(list_frame)
        button_frame.pack(padx=5, pady=5, fill=tk.X)
        
        refresh_list_button = ttk.Button(button_frame, text="刷新列表", command=self.refresh_file_list)
        refresh_list_button.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        download_button = ttk.Button(button_frame, text="下載選擇的文件", command=self.download_file)
        download_button.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
        
        delete_file_button = ttk.Button(button_frame, text="刪除選擇的文件", command=self.delete_uploaded_file)
        delete_file_button.pack(side=tk.LEFT, padx=5, fill=tk.X, expand=True)
    
    def browse_file(self):
        """瀏覽文件"""
        file_path = filedialog.askopenfilename(title="選擇文件")
        if file_path:
            self.file_path_entry.delete(0, tk.END)
            self.file_path_entry.insert(0, file_path)
            
            # 自動填入金鑰名稱（使用文件名）
            file_name = os.path.basename(file_path)
            self.upload_key_entry.delete(0, tk.END)
            self.upload_key_entry.insert(0, file_name)
    
    def upload_file(self):
        """上傳文件"""
        if not self.client.authenticated:
            messagebox.showerror("錯誤", "請先登入")
            self.tab_control.select(0)  # 切換到登入標籤頁
            return
        
        key = self.upload_key_entry.get()
        file_path = self.file_path_entry.get()
        
        if not key:
            messagebox.showerror("錯誤", "請輸入金鑰名稱")
            return
        
        if not file_path or not os.path.exists(file_path):
            messagebox.showerror("錯誤", "請選擇有效的文件")
            return
        
        result = self.client.upload_file(key, file_path)
        
        if result == "OK":
            messagebox.showinfo("成功", f"文件已上傳，金鑰為: {key}")
            self.refresh_file_list()
            
            # 清空輸入欄位
            self.upload_key_entry.delete(0, tk.END)
            self.file_path_entry.delete(0, tk.END)
        else:
            messagebox.showerror("上傳失敗", result)
    
    def refresh_file_list(self):
        """刷新文件列表"""
        if not self.client.authenticated:
            messagebox.showerror("錯誤", "請先登入")
            self.tab_control.select(0)  # 切換到登入標籤頁
            return
        
        # 清空列表
        for item in self.file_list.get_children():
            self.file_list.delete(item)
        
        # 獲取文件列表
        keys = self.client.list_keys()
        
        # 添加文件到列表
        for key in keys:
            data_type, data_size, _ = self.client.get(key)
            if data_type != "ERROR":
                self.file_list.insert("", tk.END, values=(key, data_type, f"{data_size} 字節"))
    
    def download_file(self):
        """下載選擇的文件"""
        if not self.client.authenticated:
            messagebox.showerror("錯誤", "請先登入")
            self.tab_control.select(0)  # 切換到登入標籤頁
            return
        
        selected = self.file_list.selection()
        if not selected:
            messagebox.showerror("錯誤", "請先選擇一個文件")
            return
        
        key = self.file_list.item(selected[0])["values"][0]
        
        # 獲取保存路徑
        save_path = filedialog.asksaveasfilename(title=f"保存文件 {key}", initialfile=key)
        if not save_path:
            return
        
        # 獲取文件數據
        data_type, data_size, data = self.client.get(key)
        
        if data_type == "ERROR":
            messagebox.showerror("錯誤", "獲取文件失敗")
            return
        
        # 保存文件
        try:
            with open(save_path, "wb") as f:
                f.write(data)
            messagebox.showinfo("成功", f"文件已保存到: {save_path}")
        except Exception as e:
            messagebox.showerror("保存失敗", str(e))
    
    def delete_uploaded_file(self):
        """刪除選擇的上傳文件"""
        if not self.client.authenticated:
            messagebox.showerror("錯誤", "請先登入")
            self.tab_control.select(0)  # 切換到登入標籤頁
            return
        
        selected = self.file_list.selection()
        if not selected:
            messagebox.showerror("錯誤", "請先選擇一個文件")
            return
        
        key = self.file_list.item(selected[0])["values"][0]
        
        if messagebox.askyesno("確認刪除", f"確定要刪除文件 {key} 嗎？"):
            result = self.client.delete(key)
            
            if result == "OK":
                messagebox.showinfo("成功", f"文件已刪除: {key}")
                self.refresh_file_list()
            else:
                messagebox.showerror("刪除失敗", result)
    
    # 金鑰管理相關方法
    def key_log(self, message):
        """添加金鑰管理日誌訊息"""
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.key_log_text.insert(tk.END, f"[{timestamp}] {message}\n")
        self.key_log_text.see(tk.END)
    
    def check_current_key(self):
        """檢查當前金鑰狀態"""
        key = self.key_manager.get_current_key()
        if key:
            self.key_status_var.set("已存在")
            self.key_log("金鑰檢查: 當前金鑰存在")
        else:
            self.key_status_var.set("不存在")
            self.key_log("金鑰檢查: 當前金鑰不存在")
    
    def backup_key(self):
        """備份當前金鑰"""
        result = self.key_manager.backup_key()
        self.key_log(result)
        if result.startswith("SUCCESS"):
            messagebox.showinfo("備份成功", result)
            self.refresh_backup_list()
        else:
            messagebox.showerror("備份失敗", result)
    
    def restore_key(self):
        """從選擇的備份恢復金鑰"""
        selected = self.backup_list.selection()
        if not selected:
            messagebox.showerror("錯誤", "請先選擇一個備份")
            return
        
        timestamp = self.backup_list.item(selected[0])["values"][0]
        
        if messagebox.askyesno("確認恢復", f"確定要從 {timestamp} 的備份恢復金鑰嗎？\n這將覆蓋當前金鑰。"):
            result = self.key_manager.restore_key(timestamp)
            self.key_log(result)
            if result.startswith("SUCCESS"):
                messagebox.showinfo("恢復成功", result)
                self.check_current_key()
            else:
                messagebox.showerror("恢復失敗", result)
    
    def generate_new_key(self):
        """生成新的加密金鑰"""
        if messagebox.askyesno("確認生成", "確定要生成新的加密金鑰嗎？\n這將使用新金鑰替換當前金鑰。\n注意：新金鑰將無法解密之前加密的數據！"):
            result = self.key_manager.generate_new_key()
            self.key_log(result)
            if result.startswith("SUCCESS"):
                messagebox.showinfo("生成成功", result)
                self.check_current_key()
                self.refresh_backup_list()
            else:
                messagebox.showerror("生成失敗", result)
    
    def refresh_backup_list(self):
        """刷新備份列表"""
        # 清空列表
        for item in self.backup_list.get_children():
            self.backup_list.delete(item)
        
        # 獲取備份列表
        backups = self.key_manager.get_backup_list()
        
        if not backups:
            self.key_log("備份列表為空")
        else:
            # 填充列表
            for backup in backups:
                self.backup_list.insert("", tk.END, values=(
                    backup["timestamp"],
                    backup["datetime"],
                    backup["file"]
                ))
            self.key_log(f"已刷新備份列表，共 {len(backups)} 個備份")
    
    def on_close(self):
        if self.client.socket:
            self.client.close()
        self.destroy()

    def create_default_user(self):
        """創建默認用戶"""
        if self.client.register("admin", "admin"):
            messagebox.showinfo("Success", "Default user created successfully")
        else:
            messagebox.showerror("Error", "Failed to create default user")

    def login(self):
        """處理用戶登錄"""
        username = self.username_entry.get()
        password = self.password_entry.get()
        
        if not username or not password:
            messagebox.showerror("Error", "Please enter username and password")
            return
            
        if self.client.authenticate(username, password):
            messagebox.showinfo("Success", "Login successful")
            self.tab_control.select(self.data_tab)  # 切換到數據管理頁面
        else:
            messagebox.showerror("Error", "Login failed")

    def connect_to_server(self):
        """連接到服務器"""
        try:
            if self.client.connect():
                messagebox.showinfo("Success", "Connected to server successfully")
                self.status_var.set(self.i18n.get("connected"))
            else:
                messagebox.showerror("Error", "Failed to connect to server")
                self.status_var.set(self.i18n.get("disconnected"))
        except Exception as e:
            messagebox.showerror("Error", f"Connection error: {str(e)}")
            self.status_var.set(self.i18n.get("disconnected"))

    def register_user(self):
        """註冊新用戶"""
        username = self.reg_username_entry.get()
        password = self.reg_password_entry.get()
        confirm_password = self.reg_confirm_entry.get()
        
        if not username or not password or not confirm_password:
            messagebox.showerror("Error", "Please fill in all fields")
            return
            
        if password != confirm_password:
            messagebox.showerror("Error", "Passwords do not match")
            return
            
        if self.client.register(username, password):
            messagebox.showinfo("Success", "User registered successfully")
            self.tab_control.select(self.login_tab)  # 切換到登錄頁面
        else:
            messagebox.showerror("Error", "Registration failed")

    def delete_key(self):
        """刪除選中的鍵"""
        if not self.client.authenticated:
            messagebox.showerror("Error", "Please login first")
            return
            
        selection = self.key_list.curselection()
        if not selection:
            messagebox.showerror("Error", "Please select a key to delete")
            return
            
        key = self.key_list.get(selection[0])
        if messagebox.askyesno("Confirm", f"Are you sure you want to delete key '{key}'?"):
            if self.client.delete(key):
                messagebox.showinfo("Success", "Key deleted successfully")
                self.refresh_keys()
            else:
                messagebox.showerror("Error", "Failed to delete key")

    def refresh_keys(self):
        """刷新鍵列表"""
        if not self.client.authenticated:
            return
            
        self.key_list.delete(*self.key_list.get_children())
        keys = self.client.list_keys()
        for key in keys:
            data_type, data_size, _ = self.client.get(key)
            if data_type != "ERROR":
                self.key_list.insert("", "end", values=(key, data_type, data_size))

    def get_data(self):
        """獲取選中鍵的數據"""
        if not self.client.authenticated:
            messagebox.showerror("Error", "Please login first")
            return
            
        selection = self.key_list.selection()
        if not selection:
            messagebox.showerror("Error", "Please select a key")
            return
            
        key = self.key_list.item(selection[0])["values"][0]
        data_type, data_size, data = self.client.get(key)
        
        if data_type != "ERROR":
            self.key_entry.delete(0, tk.END)
            self.key_entry.insert(0, key)
            self.type_var.set(data_type)
            self.data_text.delete(1.0, tk.END)
            if data_type in ["text", "json", "xml"]:
                self.data_text.insert(tk.END, data.decode())
            else:
                self.data_text.insert(tk.END, f"Binary data ({data_size} bytes)")
        else:
            messagebox.showerror("Error", "Failed to get data")

    def put_data(self):
        """存儲數據"""
        if not self.client.authenticated:
            messagebox.showerror("Error", "Please login first")
            return
            
        key = self.key_entry.get()
        data_type = self.type_var.get()
        data = self.data_text.get(1.0, tk.END).strip()
        
        if not key:
            messagebox.showerror("Error", "Please enter a key")
            return
            
        if not data:
            messagebox.showerror("Error", "Please enter data")
            return
            
        if data_type in ["text", "json", "xml"]:
            data_bytes = data.encode()
        else:
            try:
                data_bytes = bytes.fromhex(data)
            except:
                messagebox.showerror("Error", "Invalid binary data format")
                return
            
        result = self.client.put(key, data_type, data_bytes)
        if result == "OK":
            messagebox.showinfo("Success", "Data stored successfully")
            self.refresh_keys()
            self.key_entry.delete(0, tk.END)
            self.data_text.delete(1.0, tk.END)
        else:
            messagebox.showerror("Error", f"Failed to store data: {result}")

    def clear_data(self):
        """清除輸入框中的數據"""
        self.key_entry.delete(0, tk.END)
        self.data_text.delete(1.0, tk.END)

    def on_key_double_click(self, event):
        """處理鍵列表的雙擊事件"""
        self.get_data()

    def create_backup(self):
        """創建備份"""
        if not self.client.authenticated:
            messagebox.showerror("Error", "Please login first")
            return
            
        result = self.client.backup()
        if result == "OK":
            messagebox.showinfo("Success", "Backup created successfully")
            self.backup_result.config(text=f"Last backup: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        else:
            messagebox.showerror("Error", f"Backup failed: {result}")

    def browse_backup(self):
        """瀏覽備份文件"""
        file_path = filedialog.askopenfilename(title="Select Backup File")
        if file_path:
            self.restore_path.delete(0, tk.END)
            self.restore_path.insert(0, file_path)

    def restore_backup(self):
        """從備份恢復"""
        if not self.client.authenticated:
            messagebox.showerror("Error", "Please login first")
            return
            
        backup_path = self.restore_path.get()
        if not backup_path:
            messagebox.showerror("Error", "Please select a backup file")
            return
            
        if messagebox.askyesno("Confirm", "Are you sure you want to restore from this backup? This will overwrite all current data."):
            result = self.client.restore(backup_path)
            if result == "OK":
                messagebox.showinfo("Success", "Backup restored successfully")
                self.refresh_keys()
            else:
                messagebox.showerror("Error", f"Restore failed: {result}")

    def delete_data(self):
        """刪除數據"""
        if not self.client.authenticated:
            messagebox.showerror("Error", "Please login first")
            return
            
        selection = self.key_list.selection()
        if not selection:
            messagebox.showerror("Error", "Please select a key")
            return
            
        key = self.key_list.item(selection[0])["values"][0]
        if messagebox.askyesno("Confirm", f"Are you sure you want to delete key '{key}'?"):
            result = self.client.delete(key)
            if result == "OK":
                messagebox.showinfo("Success", f"Key '{key}' deleted successfully")
                self.refresh_keys()
            else:
                messagebox.showerror("Error", f"Failed to delete key: {result}")

if __name__ == "__main__":
    app = OmniDBApp()
    app.mainloop() 